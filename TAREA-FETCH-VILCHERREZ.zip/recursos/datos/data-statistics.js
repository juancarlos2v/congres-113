var statistics = {
    'democratas': [],
    'total_democratas': 0,
    'republicanos': [],
    'total_republicanos': 0,
    'independientes': [],
    'total_independientes': 0,
    'total': 0
}